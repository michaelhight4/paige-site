# DRAFT hall return spots (World Design, Oct 23 2026, 1:50 AM CT)

Each hall exit returns one tile south of its town door, facing down.

| hall | town map | x | y | facing | collision at spot |
|---|---|---|---|---|---|
| fernwick_hall_int | fernwick | 23 | 19 | down | 0 |
| saltmere_hall_int | saltmere | 12 | 21 | down | 0 |
| revival_hall_int | revival_heights | 12 | 21 | down | 0 |
| frostspire_hall_int | frostspire | 12 | 21 | down | 0 |
| mirefen_hall_int | mirefen | 12 | 21 | down | 0 |
| tidewater_hall_int | tidewater_coast | 12 | 21 | down | 0 |
| lanternport_hall_int | lanternport | 12 | 21 | down | 0 |
| cindervale_hall_int | cindervale | 12 | 21 | down | 0 |
