// One-time "story ends here for now" notice (Cut A, Oct 23, 2026, coder; Gary 9:51 + 10:08 AM CT).
// Shown once, right after the script that sets the trigger flag ends (the post-battle flow of the last beatable Master),
// with a single OK choice (keyboard + tap via dialog.ask). Sets seen_wip_notice so it never shows again. No road block:
// nothing is gated on it. Trigger = beat_master_fernwick because Master 1 is the last Master with authored, beatable
// teams in this cut (the key keeps Gary's name system.wip_after_master2; move TRIGGER to Master 2's flag once Cut B lands).
export const WIP_KEY = 'system.wip_after_master2';
export const WIP_FLAG = 'seen_wip_notice';
export const TRIGGER = 'beat_master_fernwick';
export const WIP_TEXT = [
  "That's as far as the story goes for now. The rest is still being built.",
  "You're free to keep exploring. Just try not to break anything.",
];

export function wipDue(scene) {
  const f = scene?.flags;
  return !!(f && f.has(TRIGGER) && !f.has(WIP_FLAG));
}

function pages(scene) {
  let v = scene.lines;
  for (const k of WIP_KEY.split('.')) v = v?.[k];
  const p = Array.isArray(v) ? v : v?.pages;
  return Array.isArray(p) && p.length ? p : WIP_TEXT;
}

/** Wraps scene.script so the notice runs as its own script right after the triggering one. Returns the scene. */
export function attachWipNotice(scene) {
  if (!scene || scene._wipAttached || typeof scene.script !== 'function') return scene;
  scene._wipAttached = true;
  const orig = scene.script.bind(scene);
  let showing = false;
  const show = async () => {
    if (showing || !wipDue(scene) || scene.busy) return;
    showing = true;
    try {
      await orig(async () => {
        scene.setFlag(WIP_FLAG); // set first: a crash or reload mid-notice still never repeats it
        await scene.ask(pages(scene), ['OK']);
      });
    } finally { showing = false; }
  };
  scene.script = async (fn) => { await orig(fn); await show(); };
  scene.showWipNotice = show;
  return scene;
}
