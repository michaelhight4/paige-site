import './legacy.ts';

export { ColyseusSDK, Client, type JoinOptions, type EndpointSettings, type ClientOptions, type RoomAvailable, type ISeatReservation as SeatReservation } from './Client.ts';
export { type FetchFn } from './HTTP.ts';
export { Room, type InputHandle, type InputOptions } from './Room.ts';
export type { RoomClock, RoomClockLike } from './RoomClock.ts';
export { type RequestOptions } from './RoomRequest.ts';
export { Auth, type AuthSettings, type PopupSettings, type AuthResponse, type UserDataResponse, type ForgotPasswordResponse, type AuthData } from "./Auth.ts";
export { ServerError, AbortError, MatchMakeError } from './errors/Errors.ts';
export { CloseCode, ErrorCode, Protocol } from '@colyseus/shared-types'; // convenience re-export / backwards compatibility
export type { InferRoomConstructor } from './core/utils.ts';

/*
 * Serializers
 */
import { SchemaSerializer, getStateCallbacks } from "./serializer/SchemaSerializer.ts";
import { NoneSerializer } from "./serializer/NoneSerializer.ts";
import { registerSerializer } from './serializer/Serializer.ts';
export { Callbacks } from "@colyseus/schema";

export { registerSerializer, SchemaSerializer, getStateCallbacks };
registerSerializer('schema', SchemaSerializer);
registerSerializer('none', NoneSerializer);

/*
 * Prediction (high-level): Predict + Reconciler + event channels/spawns.
 * The subpath `@colyseus/sdk/predict` is the tree-shake-friendly entry; this
 * top-level re-export covers the convenience `import { Predict } from
 * "@colyseus/sdk"` form and the UMD `Colyseus.Predict` namespace.
 */
export {
    Predict,
    Reconciler,
    SimReconciler,
    PredictedSpawns,
    type PredictMode,
    type PredictOptions,
    type PredictGetOptions,
    type AttachConfig,
    type ReconcilerOptions,
    type SimReconcilerOptions,
    type StepContext,
    type PredictedSpawnsOptions,
    type SpawnEntry,
    type SpawnHandle,
} from './predict.ts';
