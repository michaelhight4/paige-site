import { createElement as h } from 'react';
export const AArrowUpSharp = (props) => h('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), h('path', {d: "M16 18h2V6h-2zm2-8h2V8h-2zm-4 0h2V8h-2zm4 2h4v-2h-4zm-6 0h4v-2h-4zM2 8h2v10H2zm6 0h2v10H8z"}), h('path', {d: "M4 12h6v2H4zM2 6h8v2H2z"}));
