import { createElement as h } from 'react';
export const AlignHorizontalDistributeEnd = (props) => h('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), h('path', {d: "M9 4H6v2h3zm2-2H9v20h2zM9 18H6v2h3zM6 6H4v12h2zm9 1h3v2h-3zm-2 2h2v6h-2zm2 6h3v2h-3zm3-13h2v20h-2z"}));
