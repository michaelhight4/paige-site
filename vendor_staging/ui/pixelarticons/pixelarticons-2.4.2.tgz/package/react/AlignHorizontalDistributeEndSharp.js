import { createElement as h } from 'react';
export const AlignHorizontalDistributeEndSharp = (props) => h('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), h('path', {d: "M9 4H6v2h3zm2-2H9v20h2zM9 18H6v2h3zM6 4H4v16h2zm9 3h3v2h-3zm-2 0h2v10h-2zm2 8h3v2h-3zm3-13h2v20h-2z"}));
