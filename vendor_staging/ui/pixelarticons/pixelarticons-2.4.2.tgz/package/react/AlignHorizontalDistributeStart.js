import { createElement as h } from 'react';
export const AlignHorizontalDistributeStart = (props) => h('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), h('path', {d: "M6 4h3v2H6zM4 2h2v20H4zm2 16h3v2H6zM9 6h2v12H9zm9 1h-3v2h3zm2 2h-2v6h2zm-2 6h-3v2h3zM15 2h-2v20h2z"}));
