import { createElement as h } from 'react';
export const AlignHorizontalJustifyStartSharp = (props) => h('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), h('path', {d: "M4 2v20H2V2zm4 2h3v2H8zM6 4h2v16H6zm2 14h3v2H8zm3-14h2v16h-2zm6 3h3v2h-3zm-2 0h2v10h-2zm2 8h3v2h-3zm3-8h2v10h-2z"}));
