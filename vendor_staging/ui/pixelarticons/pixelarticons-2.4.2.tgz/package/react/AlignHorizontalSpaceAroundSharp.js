import { createElement as h } from 'react';
export const AlignHorizontalSpaceAroundSharp = (props) => h('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), h('path', {d: "M10 6h4v2h-4zM8 6h2v12H8zm2 10h4v2h-4zm4-10h2v12h-2zM4 2v20h2V2zm14 0v20h2V2z"}));
