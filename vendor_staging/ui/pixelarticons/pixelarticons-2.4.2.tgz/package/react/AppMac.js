import { createElement as h } from 'react';
export const AppMac = (props) => h('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), h('path', {d: "M4 3h16v2H4zm0 16h16v2H4zM2 5h2v14H2zm18 0h2v14h-2zM6 7h2v2H6zm4 0h2v2h-2zm4 0h2v2h-2z"}));
