import { createElement as h } from 'react';
export const ArrowDownCircle = (props) => h('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), h('path', {d: "M11 16h2v2h-2zm0-10h2v6h-2zm-2 8h6v2H9zm-2-2h10v2H7zm11 6h2v2h-2zm0-14h2v2h-2zM4 4h2v2H4zm0 14h2v2H4zM6 2h12v2H6zm0 18h12v2H6zM2 6h2v12H2zm18 0h2v12h-2z"}));
