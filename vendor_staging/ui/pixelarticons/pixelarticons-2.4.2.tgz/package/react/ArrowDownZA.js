import { createElement as h } from 'react';
export const ArrowDownZA = (props) => h('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), h('path', {d: "M14 3h7v2h-7zm0 6h7v2h-7zm2-2h2v2h-2zm2-2h2v2h-2zM6 3h2v18H6z"}), h('path', {d: "M4 17h6v2H4zm-2-2h10v2H2zm12 0h2v6h-2zm2-2h3v2h-3zm3 2h2v6h-2zm-3 2h3v2h-3z"}));
