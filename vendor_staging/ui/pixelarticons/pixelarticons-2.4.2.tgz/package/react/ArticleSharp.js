import { createElement as h } from 'react';
export const ArticleSharp = (props) => h('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), h('path', {d: "M6 2h16v2H6zm0 2h2v16H6zm14 0h2v16h-2zM2 20h20v2H2zm0-9h2v9H2zm0-2h4v2H2zm8-3h8v2h-8zm0 4h8v2h-8zm0-2h2v2h-2zm6 0h2v2h-2zm-6 5h8v2h-8zm0 3h4v2h-4z"}));
