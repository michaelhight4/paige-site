import { createElement as h } from 'react';
export const AudioWaveformSharp = (props) => h('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), h('path', {d: "M3 7h2v5H3zm4 0h2v13H7zm4-3h2v16h-2zm4 0h2v13h-2zM3 5h6v2H3zm4 15h6v2H7zm4-18h6v2h-6zm4 15h6v2h-6zm4-5h2v5h-2zm0-2h4v2h-4zM1 12h4v2H1z"}));
