import { createElement as h } from 'react';
export const BatteryLowSharp = (props) => h('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), h('path', {d: "M4 5h14v2H4zm0 12h14v2H4zM2 5h2v14H2zm16 0h2v14h-2zm2 4h2v6h-2zM6 9h2v6H6z"}));
