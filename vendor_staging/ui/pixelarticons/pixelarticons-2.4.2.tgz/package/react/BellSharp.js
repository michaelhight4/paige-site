import { createElement as h } from 'react';
export const BellSharp = (props) => h('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), h('path', {d: "M9 2h6v2H9zM7 4h2v2H7zm8 0h2v2h-2zM5 6h2v7H5zm12 0h2v7h-2zM3 13h2v4H3zm16 0h2v4h-2z"}), h('path', {d: "M3 15h18v2H3zm5 3h2v2H8zm6 0h2v2h-2zm-6 2h8v2H8z"}));
