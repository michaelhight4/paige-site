import { createElement as h } from 'react';
export const BriefcasesSharp = (props) => h('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), h('path', {d: "M6 8h2v8H6zm14 0h2v8h-2zM6 6h16v2H6zm0 10h16v2H6zm-4-4h2v8H2zm0 8h16v2H2zm8-16h2v2h-2zm0-2h8v2h-8zm6 2h2v2h-2zM2 10h4v2H2zm14 8h2v2h-2z"}));
