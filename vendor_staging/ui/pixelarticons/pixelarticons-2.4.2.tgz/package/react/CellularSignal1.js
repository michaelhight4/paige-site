import { createElement as h } from 'react';
export const CellularSignal1 = (props) => h('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), h('path', {d: "M4 12h2v6H4zm7-2h2v2h-2zm7-6h2v2h-2zM2 14h2v4H2zm7-2h2v6H9zm7-6h2v12h-2zM6 12h2v6H6zm7-2h2v8h-2zm7-6h2v14h-2zM2 18h6v2H2zm7 0h6v2H9zm7 0h6v2h-6z"}));
