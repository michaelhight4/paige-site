import { createElement as h } from 'react';
export const ChevronRight2 = (props) => h('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), h('path', {d: "M9 17h2v-2h2v-2h2v-2h-2V9h-2V7H9v10Z"}));
