import { createElement as h } from 'react';
export const ComputerSharp = (props) => h('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), h('path', {d: "M4 1h16v2H4zm0 8h16v2H4zm0-6h2v6H4zm14 0h2v6h-2zM2 13h20v2H2zm0 8h20v2H2zm0-6h2v6H2zm18 0h2v6h-2zM6 17h2v2H6zm4 0h8v2h-8zm-2-6h2v2H8zm6 0h2v2h-2z"}));
