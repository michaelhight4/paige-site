import { createElement as h } from 'react';
export const CropSharp = (props) => h('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), h('path', {d: "M8 6h10v10h4v2h-4v4h-2V8H2V6h4V2h2v4Zm0 10h6v2H6v-8h2v6Z"}));
