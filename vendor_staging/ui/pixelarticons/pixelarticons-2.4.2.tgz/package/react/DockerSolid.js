import { createElement as h } from 'react';
export const DockerSolid = (props) => h('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), h('path', {d: "M20 16h-2v2h-2v2H6v-2H4v-2H2v-6h16V8h2v8ZM7 15h2v-2H7v2ZM6 8H4V6h2v2Zm3 0H7V6h2v2Zm3 0h-2V6h2v2Zm6 0h-2V6h2v2Zm4 0h-2V6h2v2ZM9 5H7V3h2v2Zm3 0h-2V3h2v2Z"}));
