import { createElement as h } from 'react';
export const DoorClosedSharp = (props) => h('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), h('path', {d: "M3 19h18v2H3zM5 5h2v14H5zm0-2h14v2H5zm12 2h2v14h-2zm-8 6h2v2H9z"}));
