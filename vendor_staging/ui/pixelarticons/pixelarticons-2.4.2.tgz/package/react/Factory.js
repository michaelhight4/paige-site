import { createElement as h } from 'react';
export const Factory = (props) => h('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), h('path', {d: "M2 4h2v16H2zm2 16h16v2H4zM20 7h2v13h-2zm-2 0h2v2h-2zm-6 0h2v2h-2zm4 2h2v2h-2zm-6 0h2v2h-2zm4-2h2v6h-2zM8 4h2v9H8zM4 2h6v2H4zm3 13h2v2H7zm4 0h2v2h-2zm4 0h2v2h-2z"}));
