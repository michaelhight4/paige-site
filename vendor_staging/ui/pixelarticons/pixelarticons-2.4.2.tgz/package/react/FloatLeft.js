import { createElement as h } from 'react';
export const FloatLeft = (props) => h('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), h('path', {d: "M12 6h10v2H12zm0 4h10v2H12zM2 14h20v2H2zm0 4h20v2H2zM4 4h4v2H4zm0 6h4v2H4zM2 6h2v4H2zm6 0h2v4H8z"}));
