import { createElement as h } from 'react';
export const FloatRight = (props) => h('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), h('path', {d: "M2 6h10v2H2zm0 4h10v2H2zm0 4h20v2H2zm0 4h20v2H2zM16 4h4v2h-4zm0 6h4v2h-4zm-2-4h2v4h-2zm6 0h2v4h-2z"}));
