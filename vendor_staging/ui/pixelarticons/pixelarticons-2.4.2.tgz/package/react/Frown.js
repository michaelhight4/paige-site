import { createElement as h } from 'react';
export const Frown = (props) => h('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), h('path', {d: "M6 20h12v2H6zM6 2h12v2H6zm12 2h2v2h-2zM4 4h2v2H4zm0 14h2v2H4zm14 0h2v2h-2zM2 6h2v12H2zm18 0h2v12h-2zM8 8h2v2H8zm6 0h2v2h-2zm-7 7h2v2H7zm2-2h6v2H9zm6 2h2v2h-2z"}));
