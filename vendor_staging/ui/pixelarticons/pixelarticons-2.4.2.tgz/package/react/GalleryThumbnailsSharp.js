import { createElement as h } from 'react';
export const GalleryThumbnailsSharp = (props) => h('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), h('path', {d: "M4 2h16v2H4zM2 2h2v16H2zm2 14h16v2H4zM20 2h2v16h-2zM3 20h3v2H3zm5 0h3v2H8zm5 0h3v2h-3zm5 0h3v2h-3z"}));
