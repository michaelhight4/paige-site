import { createElement as h } from 'react';
export const Gamepad = (props) => h('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), h('path', {d: "M4 4h16v2H4zm0 14h16v2H4zM2 6h2v12H2zm18 0h2v12h-2zM8 9h2v6H8z"}), h('path', {d: "M6 11h6v2H6zm8-2h2v2h-2zm2 4h2v2h-2z"}));
