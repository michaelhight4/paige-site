import { createElement as h } from 'react';
export const Gps2Sharp = (props) => h('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), h('path', {d: "M7 5h10v2H7zm10 0h2v14h-2zM7 17h10v2H7zM5 5h2v14H5zm14 6h4v2h-4zM1 11h4v2H1zM11 1h2v4h-2zm0 18h2v4h-2zm0-10h2v2h-2zm-2 2h2v2H9zm2 2h2v2h-2zm2-2h2v2h-2z"}));
