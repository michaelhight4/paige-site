import { createElement as h } from 'react';
export const Grid2x3 = (props) => h('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), h('path', {d: "M4 2h16v2H4zm0 18h16v2H4zM2 4h2v16H2zm18 0h2v16h-2zm-7 0v16h-2V4z"}), h('path', {d: "M20 8v2H4V8zm0 6v2H4v-2z"}));
