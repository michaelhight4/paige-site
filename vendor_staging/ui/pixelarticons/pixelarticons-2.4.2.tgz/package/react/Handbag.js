import { createElement as h } from 'react';
export const Handbag = (props) => h('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), h('path', {d: "M7 4h2v7H7zm2-2h6v2H9zm6 2h2v7h-2z"}), h('path', {d: "M5 7h14v2H5zm14 2h2v5h-2zM5 9H3v5h2zm16 5h2v6h-2zM3 14H1v6h2zm0 6h18v2H3z"}));
