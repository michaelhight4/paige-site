import { createElement as h } from 'react';
export const Heading2 = (props) => h('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), h('path', {d: "M3 6h2v12H3z"}), h('path', {d: "M3 11h10v2H3z"}), h('path', {d: "M11 6h2v12h-2zm4 10h6v2h-6zm0-2h2v2h-2zm2-2h2v2h-2zm2-2h2v2h-2zm-2-2h2v2h-2zm-2 0h2v2h-2z"}));
